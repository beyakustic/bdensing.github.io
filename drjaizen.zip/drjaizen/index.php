<?php

	//php code inside//
	get_header();
?>
	
				<div id="banner">
					<div class="wsite-header"></div>
				</div>
				<div id="main">
					<div id="content">
						<div id="wsite-content" class="wsite-elements wsite-not-footer">
							<div>
								<div class="wsite-multicol">
									<div class="wsite-multicol-table-wrap" style="margin:0px -15px;">
										<table class="wsite-multicol-table">
											<tbody class="wsite-multicol-tbody">
												<tr class="wsite-multicol-tr">
													<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 15px;">
														<div>
															<div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
																<a>
																	<img src="<?php bloginfo('template_url'); ?>/images/9816840.png" alt="Picture" style="width:100%;max-width:280px">
																</a>
																<div style="display:block;font-size:90%"></div>
															</div>
														</div>
														<div class="paragraph" style="text-align:justify;">
															Dental implants is a restorative dentistry option that allows patients to replace missing teeth with ones that look, feel and perform like their own...
														</div>
														<div style="text-align:right;">
															<div style="height: 0px; overflow: hidden;"></div>
															<a class="wsite-button wsite-button-small wsite-button-highlight" href="/dental-treatments-information.html">
																<span class="wsite-button-inner">read more</span>
															</a>
															<div style="height: 0px; overflow: hidden;"></div>
														</div>
													</td>
													<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 15px;">
														<div>
															<div class="wsite-image wsite-image-border-medium " style="padding-top:15px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
																<a>
																	<img src="<?php bloginfo('template_url'); ?>/images/7688167.jpg" alt="Picture" style="width:auto;max-width:100%">
																</a>
																<div style="display:block;font-size:90%"></div>
															</div>
														</div>
													</td>
													<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 15px;">
														<div>
															<div class="wsite-image wsite-image-border-medium " style="padding-top:15px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
															<a>
																<img src="<?php bloginfo('template_url'); ?>/images/2492391_orig.jpg" alt="Picture" style="width:100%;max-width:1100px">
															</a>
															<div style="display:block;font-size:90%"></div>
														</div>
													</div>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
						<div>
							<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
							<a>
								<img src="<?php bloginfo('template_url'); ?>/images/572156_orig.png" alt="Picture" style="width:100%;max-width:880px">
							</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>
					<div class="paragraph" style="text-align:center;">
						<font size="3">KNOW YOUR DENTAL TREATMENT</font>
					</div>
					<div>
						<div class="wsite-multicol">
							<div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
								<table class="wsite-multicol-table">
									<tbody class="wsite-multicol-tbody">
										<tr class="wsite-multicol-tr">
											<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 15px;">
												<div>
													<div class="wsite-image wsite-image-border-none" style="padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
													<a>
														<img src="<?php bloginfo('template_url'); ?>/images/2526710_orig.png" alt="Picture" style="width:100%;max-width:259px">
													</a>
													<div style="display:block;font-size:90%"></div>
												</div>
											</div>
											<div>
												<div style="height: 0px; overflow: hidden; width: 100%;"></div>
												<hr class="styled-hr" style="width:100%;">
												<div style="height: 0px; overflow: hidden; width: 100%;"></div>
											</div>
											<div class="paragraph" style="text-align:justify;">
												Orthodontic treatment aims at bringing teeth and jaws into a harmonious position with the 
												face. This may improve the appearance, oral health and function...
											</div>
											<div style="text-align:right;">
												<div style="height:0px; overflow:hidden;"></div>
												<a class="wsite-button wsite-button-small wsite-button-highlight" href="/dental-treatments-information.html">
													<span class="wsite-button-inner">read more</span>
												</a>
												<div style="height: 0px; overflow: hidden;"></div>
											</div>
										</td>
										<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 15px;">
											<div>
												<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
													<a>
														<img src="<?php bloginfo('template_url'); ?>/images/7859388_orig.png" alt="Picture" style="width:100%;max-width:259px">
													</a>
													<div style="display:block;font-size:90%"></div>
												</div>
											</div>
											<div>
												<div style="height: 0px; overflow: hidden; width: 100%;"></div>
												<hr class="styled-hr" style="width:100%;">
												<div style="height: 0px; overflow: hidden; width: 100%;"></div>
											</div>
											<div class="paragraph" style="text-align:justify;">
												If dental plaque is allowed to accumulate on or around a wisdom tooth, the tooth and the 
												tissues that surround it will be at risk for tooth decay (cavities)...
											</div>
											<div style="text-align:right;">
												<div style="height: 0px; overflow: hidden;"></div>
												<a class="wsite-button wsite-button-small wsite-button-highlight" href="/dental-treatments-information.html">
													<span class="wsite-button-inner">read more</span>
												</a>
												<div style="height: 0px; overflow: hidden;"></div>
											</div>
										</td>
										<td class="wsite-multicol-col" style="width:33.333333333333%; padding:0 15px;">
											<div>
												<div class="wsite-image wsite-image-border-none" style="padding-top:0;padding-bottom:0;margin-left:0;
													margin-right:0;text-align:center;">
													<a>
														<img src="<?php bloginfo('template_url'); ?>/images/7944538_orig.png" alt="Picture" style="width:100%;max-width:259px">
													</a>
													<div style="display:block;font-size:90%"></div>
												</div>
											</div>
											<div>
												<div style="height: 0px; overflow: hidden; width: 100%;"></div>
												<hr class="styled-hr" style="width:100%;">
												<div style="height: 0px; overflow: hidden; width: 100%;"></div>
											</div>
											<div class="paragraph" style="text-align:justify;">
												The most common causes of bad breath are preventable and can easily be treated, however certain medical conditions may also cause bad breath...
											</div>
											<div style="text-align:right;">
												<div style="height: 0px; overflow: hidden;"></div>
												<a class="wsite-button wsite-button-small wsite-button-highlight" href="/dental-treatments-information.html">
													<span class="wsite-button-inner">read more</span>
												</a>
												<div style="height: 0px; overflow: hidden;"></div>
											</div>
										</td>
									<tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
		get_footer();
	?>