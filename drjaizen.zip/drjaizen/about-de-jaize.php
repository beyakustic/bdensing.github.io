<?php

	//php code inside//
	get_header();
?>

<div id="banner">
				<div class="wsite-header"></div>
			</div>
			<div id="main">
				<div id="content">
					<div id="wsite-content" class="wsite-elements wsite-not-footer">
						<div>
							<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
								<a>
									<img src="<?php bloginfo('template_url'); ?>/images/1357326_orig.png" alt="Picture" style="width:100%;max-width:426px">
								</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>
					<div>
						<div class="wsite-multicol">
							<div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
								<table class="wsite-multicol-table">
									<tbody class="wsite-multicol-tbody">
										<tr class="wsite-multicol-tr">
											<td class="wsite-multicol-col" style="width:50%; padding:0 15px;">								
												<div>
													<div class="wsite-image wsite-image-border-thin " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
														<a>
															<img src="<?php bloginfo('template_url'); ?>/images/8041339_orig.jpg" alt="Picture" style="width:100%;max-width:1100px">
														</a>
														<div style="display:block;font-size:90%"></div>
													</div>
												</div>					
											</td>				
											<td class="wsite-multicol-col" style="width:50%; padding:0 15px;">											
												<div class="paragraph" style="text-align:justify;">
													<br>
													<font size="3">Dr. Jaizen Agnes Aguilar is a promising and talented oral surgeon and implantologist. She finished her advanced 
														implant course at University of British Columbia, She also won for best in Thesis. Her patients knows her for having the "magic hands". 
														what made her different among the other dentist is that she works with passion. She also used to be part of New World Renaissance Hotel 
														and Asian Development Bank as consultant in the field of dentistry.
													</font>
													<br>
												</div>					
											</td>			
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div>
						<div class="wsite-multicol">
							<div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
								<table class="wsite-multicol-table">
									<tbody class="wsite-multicol-tbody">
										<tr class="wsite-multicol-tr">
											<td class="wsite-multicol-col" style="width:61.233480176211%; padding:0 15px;">										
												<div class="paragraph" style="text-align:left;">
													<font size="3">Member of the following dental organizations:
														<br>
													</font>
													<ul style="">
														<li style="">
															<font size="3">Philippine Dental Association</font>
														</li>
														<li style="">
															<font size="3">Philippine Academy of Implant Dentistry</font>
														</li>
														<li style="">
															<font size="3">Asia-Pacific - International Congress of Oral Implantologist</font>
														</li>
														<li style="">
															<font size="3">World - International Congress of Oral Implantologist</font>
														</li>
													</ul>
												</div>					
											</td>				
											<td class="wsite-multicol-col" style="width:38.766519823789%; padding:0 15px;">											
												<div>
													<div style="height: 10px; overflow: hidden;"></div>
														<div id="715603413300143731-gallery" class="imageGallery" style="line-height: 0px; padding: 0; margin: 0">
															<div id="715603413300143731-imageContainer0" style="float:left;width:33.28%;margin:0;">
																<div id="715603413300143731-insideImageContainer0" style="position:relative;margin:1px;">
																	<div class="galleryImageBorder" style="border-width:1px;padding:3px;">
																		<div class="galleryImageHolder" style="position:relative; width:100%; padding:0 0 100%;overflow:hidden;">
																			<div class="galleryInnerImageHolder">
																				<a href="<?php bloginfo('template_url'); ?>/images/3682254_orig.jpg" rel="lightbox[gallery715603413300143731]" onclick="if (!window.lightboxLoaded) return false" class="w-fancybox">
																					<img src="<?php bloginfo('template_url'); ?>/images/3682254.jpg" class="galleryImage" _width="333" _height="220" style="position:absolute;border:0;width:151.36%;top:0%;left:-25.68%">
																				</a>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
															<div id="715603413300143731-imageContainer1" style="float:left;width:33.28%;margin:0;"><div id="715603413300143731-insideImageContainer1" style="position:relative;margin:1px;">
																<div class="galleryImageBorder" style="border-width:1px;padding:3px;">
																	<div class="galleryImageHolder" style="position:relative; width:100%; padding:0 0 100%;overflow:hidden;">
																		<div class="galleryInnerImageHolder">
																			<a href="<?php bloginfo('template_url'); ?>/images/6692229_orig.jpg" rel="lightbox[gallery715603413300143731]" onclick="if (!window.lightboxLoaded) return false" class="w-fancybox">
																				<img src="<?php bloginfo('template_url'); ?>/images/6692229.jpg" class="galleryImage" _width="333" _height="220" style="position:absolute;border:0;width:151.36%;top:0%;left:-25.68%">
																			</a>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<div id="715603413300143731-imageContainer2" style="float:left;width:33.28%;margin:0;">
															<div id="715603413300143731-insideImageContainer2" style="position:relative;margin:1px;">
																<div class="galleryImageBorder" style="border-width:1px;padding:3px;">
																	<div class="galleryImageHolder" style="position:relative; width:100%; padding:0 0 100%;overflow:hidden;">
																		<div class="galleryInnerImageHolder">
																			<a href="<?php bloginfo('template_url'); ?>/images/2833575_orig.jpg" rel="lightbox[gallery715603413300143731]" onclick="if (!window.lightboxLoaded) return false" class="w-fancybox">
																				<img src="<?php bloginfo('template_url'); ?>/images/2833575.jpg" class="galleryImage" _width="333" _height="220" style="position:absolute;border:0;width:151.36%;top:0%;left:-25.68%">
																			</a>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<span style="display: block; clear: both; height: 0px; overflow: hidden;"></span>
													</div>
													<div style="height: 10px; overflow: hidden;"></div>
												</div>					
											</td>			
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div>
						<div style="height: 20px; overflow: hidden;"></div>
						<div id="401993487219947558-gallery" class="imageGallery" style="line-height: 0px; padding: 0; margin: 0">
							<div id="401993487219947558-imageContainer0" style="float:left;width:33.28%;margin:0;">
								<div id="401993487219947558-insideImageContainer0" style="position:relative;margin:5px;">
									<div class="galleryImageBorder" style="border-width:1px;padding:3px;">
										<div class="galleryImageHolder" style="position:relative; width:100%; padding:0 0 75%;overflow:hidden;">
											<div class="galleryInnerImageHolder">
												<a href="<?php bloginfo('template_url'); ?>/images/8345424_orig.jpg" rel="lightbox[gallery401993487219947558]" onclick="if (!window.lightboxLoaded) return false" class="w-fancybox">
													<img src="<?php bloginfo('template_url'); ?>/images/8345424.jpg" class="galleryImage" _width="333" _height="249" style="position:absolute;border:0;width:100.3%;top:0%;left:-0.15%">
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div id="401993487219947558-imageContainer1" style="float:left;width:33.28%;margin:0;">
								<div id="401993487219947558-insideImageContainer1" style="position:relative;margin:5px;">
									<div class="galleryImageBorder" style="border-width:1px;padding:3px;">
										<div class="galleryImageHolder" style="position:relative; width:100%; padding:0 0 75%;overflow:hidden;">
											<div class="galleryInnerImageHolder">
												<a href="<?php bloginfo('template_url'); ?>/images/8718367_orig.jpg" rel="lightbox[gallery401993487219947558]" onclick="if (!window.lightboxLoaded) return false" class="w-fancybox">
													<img src="<?php bloginfo('template_url'); ?>/images/8718367.jpg" class="galleryImage" _width="187" _height="250" style="position:absolute;border:0;width:100%;top:-39.13%;left:0%">
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div id="401993487219947558-imageContainer2" style="float:left;width:33.28%;margin:0;">
								<div id="401993487219947558-insideImageContainer2" style="position:relative;margin:5px;">
									<div class="galleryImageBorder" style="border-width:1px;padding:3px;">
										<div class="galleryImageHolder" style="position:relative; width:100%; padding:0 0 75%;overflow:hidden;">
											<div class="galleryInnerImageHolder">
												<a href="<?php bloginfo('template_url'); ?>/images/8368571_orig.jpg" rel="lightbox[gallery401993487219947558]" onclick="if (!window.lightboxLoaded) return false" class="w-fancybox">
													<img src="<?php bloginfo('template_url'); ?>/images/8368571.jpg" class="galleryImage" _width="187" _height="250" style="position:absolute;border:0;width:100%;top:-39.13%;left:0%">
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<span style="display: block; clear: both; height: 0px; overflow: hidden;"></span>
						</div>
						<div style="height: 20px; overflow: hidden;"></div>
					</div>
				</div>
			</div>
		</div>
		
		<?php
		get_footer();
	?>