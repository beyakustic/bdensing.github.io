<!DOCTYPE html>
<html>
	<head>
		<title>828 Raies Dental Clinic - Home</title>
		<meta property="og:site_name" content="828 Raies Dental Clinic">
		<meta property="og:title" content="828 Raies Dental Clinic">
		<meta property="og:description" content="Dental implants is a restorative dentistry option that allows patients to replace missing teeth with ones that look, feel and perform like their own...">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/1376571940.png">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/9816840.png">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/7688167.jpg?267">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/2492391_orig.jpg">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/572156_orig.png">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/2526710_orig.png">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/7859388_orig.png">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/7944538_orig.png">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/8462030.png?26">
		<meta property="og:image" content="<?php bloginfo('template_url'); ?>/images/2092315.png?187">
		<meta property="og:url" content="http://www.drjaizendental.com/">

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

		<link rel="stylesheet" href="//cdn2.editmysite.com/css/sites.css?buildTime=1424377651" type="text/css"><link rel="stylesheet" type="text/css" href="//cdn1.editmysite.com/editor/libraries/fancybox/fancybox.css?1424377651">
		<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/main_style.css?1424395188" title="wsite-theme-css">
		<link href="//fonts.googleapis.com/css?family=Maven+Pro:400,700&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<link href="//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,700,400italic,700italic&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<link href="//cdn1.editmysite.com/editor/fonts/Sapir/font.css?2" rel="stylesheet" type="text/css">
		<link href="//fonts.googleapis.com/css?family=Gentium+Basic:400,700,400italic,700italic&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		
		<style type="text/css">		
			.wsite-elements.wsite-not-footer div.paragraph, .wsite-elements.wsite-not-footer p, .wsite-elements.wsite-not-footer .product-block .product-title, .wsite-elements.wsite-not-footer .product-description, .wsite-elements.wsite-not-footer .wsite-form-field label, .wsite-elements.wsite-not-footer .wsite-form-field label, #wsite-content div.paragraph, #wsite-content p, #wsite-content .product-block .product-title, #wsite-content .product-description, #wsite-content .wsite-form-field label, #wsite-content .wsite-form-field label, .blog-sidebar div.paragraph, .blog-sidebar p, .blog-sidebar .wsite-form-field label, .blog-sidebar .wsite-form-field label {font-family:"Open Sans" !important;}
			#wsite-content div.paragraph, #wsite-content p, #wsite-content .product-block .product-title, #wsite-content .product-description, #wsite-content .wsite-form-field label, #wsite-content .wsite-form-field label, .blog-sidebar div.paragraph, .blog-sidebar p, .blog-sidebar .wsite-form-field label, .blog-sidebar .wsite-form-field label {color:#3f3f3f !important;}
			.wsite-elements.wsite-footer div.paragraph, .wsite-elements.wsite-footer p, .wsite-elements.wsite-footer .product-block .product-title, .wsite-elements.wsite-footer .product-description, .wsite-elements.wsite-footer .wsite-form-field label, .wsite-elements.wsite-footer .wsite-form-field label{}
			.wsite-elements.wsite-not-footer h2, .wsite-elements.wsite-not-footer .product-long .product-title, .wsite-elements.wsite-not-footer .product-large .product-title, .wsite-elements.wsite-not-footer .product-small .product-title, #wsite-content h2, #wsite-content .product-long .product-title, #wsite-content .product-large .product-title, #wsite-content .product-small .product-title, .blog-sidebar h2 {font-family:"Sapir" !important;font-size:24px !important;}
			#wsite-content h2, #wsite-content .product-long .product-title, #wsite-content .product-large .product-title, #wsite-content .product-small .product-title, .blog-sidebar h2 {color:#2a2a2a !important;}
			.wsite-elements.wsite-footer h2, .wsite-elements.wsite-footer .product-long .product-title, .wsite-elements.wsite-footer .product-large .product-title, .wsite-elements.wsite-footer .product-small .product-title{}
			#wsite-title {font-family:"Gentium Basic" !important;font-size:34px !important;color:#d5d5d5 !important;}
			.wsite-not-footer h2.wsite-content-title a, .wsite-not-footer .paragraph a, .wsite-not-footer blockquote a, #blogTable .blog-sidebar a, #blogTable .blog-comments a, #blogTable .blog-comments-bottom a, #wsite-com-store a, #wsite-com-product-gen a, #wsite-com-product-tab a {color:#626262 !important;}
			.wsite-menu-default a {}
			.wsite-menu a {}
			.wsite-image div, .wsite-caption {}
			.galleryCaptionInnerText {}
			.fancybox-title {}
			.wslide-caption-text {}
			.wsite-phone {}
			.wsite-headline {}
			.wsite-headline-paragraph {}
			.wsite-button-inner {}
			.wsite-not-footer blockquote, #wsite-com-product-tab blockquote {}
			.wsite-footer blockquote {}
			.blog-header h2 a {}
			#wsite-content h2.wsite-product-title {}
			.wsite-product .wsite-product-price a {}
			.wsite-not-footer h2.wsite-content-title a:hover, .wsite-not-footer .paragraph a:hover, .wsite-not-footer blockquote a:hover, #blogTable .blog-sidebar a:hover, #blogTable .blog-comments a:hover, #blogTable .blog-comments-bottom a:hover, #wsite-com-store a:hover, #wsite-com-product-gen a:hover, #wsite-com-product-tab a:hover {color:#3f3f3f !important;}
		</style>

		<style type="text/css">
			.wsite-header {
				background-image: url(<?php bloginfo('template_url'); ?>/images/1375872279.jpg) !important;
				background-position: 0 0 !important;
			}
		</style>
		
		<script src="http://edge.quantserve.com/quant.js" async="" type="text/javascript"></script>
		<script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script>
		<script><!--
			var STATIC_BASE = '//cdn1.editmysite.com/';
			var STYLE_PREFIX = 'wsite';
			//-->
		</script>
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
		<script src="//cdn2.editmysite.com/js/site/main.js?buildTime=1424377651"></script>
		<script>_W.relinquish && _W.relinquish()</script>
		<script type="text/javascript"><!--
			(function(jQuery){
			function initFlyouts(){initPublishedFlyoutMenus([{"id":"633612536492264621","title":"Home","url":"index.html","target":""},{"id":"791694480813508553","title":"About Dr. Jaizen","url":"about-dr-jaizen.html","target":""},{"id":"453191559569085705","title":"Our Clinic and Services","url":"our-clinic-and-services.html","target":""},{"id":"790157664275769546","title":"Contact Us","url":"contact-us.html","target":""}],"633612536492264621","<li><a href=\"#\" data-membership-required=\"\" >{{title}}<\/a><\/li>",'active',false)}
			if (jQuery) {
			jQuery(document).ready(function() { jQuery(initFlyouts); });
			}else{
			if (Prototype.Browser.IE) window.onload = initFlyouts;
			else document.observe('dom:loaded', initFlyouts);
			}
			})(window._W && _W.jQuery)
			//-->
		</script>
	</head>
	
	<body class=" tall-header-page  wsite-theme-light wsite-page-index">
		<div id="container">
			<div id="header-top">
				<table id="header-right">
					<tbody>
						<tr>
							<td class="phone-number">
								<span class="wsite-text wsite-phone">Making you smile is our top priority.</span>
							</td>
							<td class="social">
								<div style="text-align:left;">
									<div style="height:0px;overflow:hidden"></div>
									<span class="wsite-social wsite-social-default">
										<a class="first-child wsite-social-item wsite-social-facebook" href="http://www.facebook.com/jaizen.aguilar" target="_blank">
											<span class="wsite-social-item-inner"></span>
										</a>
										<a class="last-child wsite-social-item wsite-social-mail" href="mailto:dr.jaaraies@yahoo.com" target="_blank">
											<span class="wsite-social-item-inner"></span>
										</a>
									</span>
									<div style="height:0px;overflow:hidden"></div>
								</div>
							</td>
							<td class="search">
								<span class="wsite-search">
									<form id="wsite-header-search-form" action="/apps/search" method="get">
										<input type="text" name="q" class="wsite-search-input" autocomplete="off" placeholder="Search">
										<span class="wsite-search-button">
											<span class="wsite-search-button-inner"></span>
										</span>
									</form>
								</span>
							</td>
						</tr>
					</tbody>
				</table>
				<div style="clear:both;"></div>
			</div>
			<div id="top-section">
				<table id="header">
					<tbody>
						<tr>
							<td id="logo">
								<span class="wsite-logo">
									<a href="<?php the_title() ?>">
										<img src="<?php bloginfo('template_url'); ?>/images/1376571940.png" style="margin-left:4px;">
									</a>
								</span>
							</td>
							<td id="header-nav">
								<ul class="wsite-menu-default">
									<li id="active" class="wsite-nav-1" style="position: relative;">
										<a href="/" style="position: relative;">Home</a>
									</li>
									<li id="pg791694480813508553" class="wsite-nav-2" style="position: relative;">
										<a href="/about-dr-jaizen.php" data-membership-required="0" style="position: relative;">About Dr. Jaizen</a>
									</li>
									<li id="pg453191559569085705" class="wsite-nav-3" style="position: relative;">
										<a href="/our-clinic-and-services.php" data-membership-required="0" style="position: relative;">Our Clinic and Services</a>
									</li>
									<li id="pg790157664275769546" class="wsite-nav-4" style="position: relative; display: none;">
										<a href="/contact-us.php" data-membership-required="0" style="position: relative;">Contact Us</a>
									</li>
									<li class="wsite-nav-more" style="position: relative;">
										<a href="#" data-membership-required="" id="wsite-nav-more-a" style="position: relative;">more...</a>
									</li>
								</ul>
							</td>
						</tr>
					</tbody>
				</table>
			</div>