<?php

	//php code inside//
	get_header();
?>

<div id="banner">
			<div class="wsite-header"></div>
		</div>
		<div id="main">
			<div id="content">
				<div id="wsite-content" class="wsite-elements wsite-not-footer">
					<div>
						<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
							<a>
								<img src="<?php bloginfo('template_url'); ?>/images/7157082_orig.png" alt="Picture" style="width:100%;max-width:259px">
							</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>
					<span class="imgPusher" style="float:left;height:0px"></span>
					<span style="display: table;z-index:10;width:auto;position:relative;float:left;max-width:100%;;clear:left;margin-top:0px;*margin-top:0px">
						<a href="<?php bloginfo('template_url'); ?>/images/6671107_orig.jpg?275" onclick="if (!lightboxLoaded) return false" class="w-fancybox">
							<img src="<?php bloginfo('template_url'); ?>/images/6671107.jpg?275" style="margin-top: 5px; margin-bottom: 10px; margin-left: 0px; margin-right: 10px; border-width:1px;padding:3px; max-width:100%" alt="Picture" class="galleryImageBorder wsite-image">
						</a>
						<span style="display: table-caption; caption-side: bottom; font-size: 90%; margin-top: -10px; margin-bottom: 10px; text-align: center;" class="wsite-caption">
						</span>
					</span>
					<div class="paragraph" style="text-align:justify;display:block;">As we age, some of us will lose teeth due to disease, injury, or 
						simple daily wear. In addition to bringing about unwanted changes to a person's facial appearance, missing teeth have a negative 
						effect on that person's confidence and self-esteem. With the advent of implant dentistry, however, those who are missing one, 
						two or several teeth no longer have to accept a lifetime of embarrassment and inconvenience. Dental implants, sturdy titanium posts 
						that are anchored directly into the jawbone and topped with realistic replacement teeth, provide the security and usability of 
						permanently placed teeth. Dental implants are a restorative dentistry option that allows patients to replace missing teeth with ones 
						look, feel and perform like their own.
					</div>
					<hr style="width:100%;clear:both;visibility:hidden;">
					<div>
						<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
							<a>
								<img src="<?php bloginfo('template_url'); ?>/images/8983213_orig.png" alt="Picture" style="width:100%;max-width:880px">
							</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>
					<div>
						<div class="wsite-image wsite-image-border-none " style="padding-top:15px;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
							<a>
								<img src="<?php bloginfo('template_url'); ?>/images/7436220_orig.png" alt="Picture" style="width:100%;max-width:259px">
							</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>
					<span class="imgPusher" style="float:left;height:0px"></span>
					<span style="display: table;z-index:10;width:auto;position:relative;float:left;max-width:100%;;clear:left;margin-top:0px;*margin-top:0px">
						<a>
							<img src="<?php bloginfo('template_url'); ?>/images/1982066.jpg?113" style="margin-top: 5px; margin-bottom: 0px; margin-left: 0px; margin-right: 10px; 
								border-width:1px;padding:6px; max-width:100%" alt="Picture" class="galleryImageBorder wsite-image">
						</a>
						<span style="display: table-caption; caption-side: bottom; font-size: 90%; margin-top: -0px; margin-bottom: 0px; text-align: center;" 
							class="wsite-caption">
						</span>
					</span>
					<div class="paragraph" style="text-align:left;display:block;">
						What is impacted 3rd molar and why do we need to remove them? In dental terminology, an "impacted" tooth refers to a tooth that has 
						failed to emerge fully into its expected position. This failure to erupt properly might occur because there is not enough room in 
						the person's jaw to accommodate the tooth, the tooth's eruption path is obstructed by other teeth. &nbsp;Some of the justifications 
						given for wisdom tooth removal have to do with the fact that they can be hard to keep clean.
					</div>
					<hr style="width:100%;clear:both;visibility:hidden;">
					<div>
						<div class="wsite-multicol">
							<div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
								<table class="wsite-multicol-table">
									<tbody class="wsite-multicol-tbody">
										<tr class="wsite-multicol-tr">
											<td class="wsite-multicol-col" style="width:62.775330396476%; padding:0 15px;">
												<div class="paragraph" style="text-align:justify;">If dental plaque is allowed to accumulate on or around a 
													wisdom tooth, the tooth and the tissues that surround it will be at risk for tooth decay (cavities), 
													periodontal disease ( gum disease), and recurring infections (pericoronitis). This is why many dentists 
													will suggest that misaligned or malpositioned wisdom teeth (impacted or not) should be extracted.
												</div>				
											</td>				
											<td class="wsite-multicol-col" style="width:37.224669603524%; padding:0 15px;">
												<div>
													<div class="wsite-image wsite-image-border-thin " style="padding-top:0;padding-bottom:10px;margin-left:0;
														margin-right:0;text-align:center">
														<a>
															<img src="<?php bloginfo('template_url'); ?>/images/8832901_orig.jpg" alt="Picture" style="width:100%;max-width:500px">
														</a>
														<div style="display:block;font-size:90%"></div>
													</div>
												</div>		
											</td>			
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div>
						<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
							<a>
								<img src="<?php bloginfo('template_url'); ?>/images/5819983_orig.png" alt="Picture" style="width:100%;max-width:880px">
							</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>
					<div>
						<div class="wsite-image wsite-image-border-none " style="padding-top:15px;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
							<a>
								<img src="<?php bloginfo('template_url'); ?>images/1860945_orig.png" alt="Picture" style="width:100%;max-width:259px">
							</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>
					<span class="imgPusher" style="float:left;height:0px"></span>
					<span style="display: table;z-index:10;width:auto;position:relative;float:left;max-width:100%;;clear:left;margin-top:0px;*margin-top:0px">
						<a>
							<img src="<?php bloginfo('template_url'); ?>/images/5679017.jpg?196" style="margin-top: 5px; margin-bottom: 0px; margin-left: 0px; margin-right: 10px; 
								border-width:1px;padding:3px; max-width:100%" alt="Picture" class="galleryImageBorder wsite-image">
						</a>
						<span style="display: table-caption; caption-side: bottom; font-size: 90%; margin-top: -0px; margin-bottom: 0px; text-align: center;" 
							class="wsite-caption">
						</span>
					</span>
					<div class="paragraph" style="text-align:justify;display:block;">
						<strong>
							<font size="3">What is orthodontics?</font>
						</strong>
						<br>Orthodontics deals with the arrangement of teeth and the way teeth come together (the bite). Orthodontic treatment aims at 
						bringing teeth and jaws into a harmonious position with the face. This may improve the appearance, oral health and function. 
						Positive results can be achieved by informed and cooperative patients.
					</div>
					<hr style="width:100%;clear:both;visibility:hidden;">
					<div>
						<div class="wsite-multicol">
							<div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
								<table class="wsite-multicol-table">
									<tbody class="wsite-multicol-tbody">
										<tr class="wsite-multicol-tr">
											<td class="wsite-multicol-col" style="width:50.660792951542%; padding:0 15px;">
												<div class="paragraph" style="text-align:justify;">
													<font size="3"><strong>Why do I need braces?</strong></font>
													<br>People have their teeth straightened for a variety of reasons. These include: dental health, 
													appearance, speech, better chewing etc. Among these, dental health is the most important. 
													Poorly aligned or crooked teeth are difficult to keep clean. They often give rise to decay and 
													gum problems.<br><br>
													<strong>
													<font size="3">When is the best time to start treatment?</font>
													</strong>
													<br>This depends on the type of orthodontic problem. For jaw-related cases, treatment generally 
													starts while the child is still growing. This is between the ages of 9 and 11. For mal-aligned 
													teeth not related to jaw problems, treatment can generally be delayed until all the primary teeth 
													(milk teeth) have changed to permanent ones.
												</div
												<span class="imgPusher" style="float:left;height:0px"></span>
												<span style="display: table;z-index:10;width:auto;position:relative;float:left;max-width:100%;;clear:left;
													margin-top:0px;*margin-top:0px">
													<a>
														<img src="<?php bloginfo('template_url'); ?>/images/1374991121.png" style="margin-top: 15px; margin-bottom: 10px; margin-left: 0px; margin-right: 10px; 
															border-width:0; max-width:100%" alt="Picture" class="galleryImageBorder wsite-image">
													</a>
													<span style="display: table-caption; caption-side: bottom; font-size: 90%; margin-top: -10px; margin-bottom: 10px; text-align: 
														center;" class="wsite-caption">
													</span>
												</span>
												<div class="paragraph" style="text-align:justify;display:block;">
													<font size="1">Many people are worried about the pain and attention braces bring. Adapting to braces can be both easy and fast. 
														Some mild discomfort will be experienced in the first week. Subsequently, you can eat or even play musical instruments 
														as normal. Colour and transparent bands are available to add variety to the look of your braces.
													</font>
												</div>
												<hr style="width:100%;clear:both;visibility:hidden;">				
											</td>				
											<td class="wsite-multicol-col" style="width:49.339207048458%; padding:0 15px;">											
												<div>
													<div class="wsite-image wsite-image-border-medium " style="padding-top:15px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
														<a>
															<img src="images/9281569_orig.jpg" alt="Picture" style="width:100%;max-width:640px">
														</a>
														<div style="display:block;font-size:90%"></div>
													</div><
												</div>
												<h2 class="wsite-content-title" style="text-align:center;">
													<font size="3">Lingual Braces</font>
												</h2>
												<div>
													<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
														<a>
															<img src="<?php bloginfo('template_url'); ?>/images/3598618_orig.jpg" alt="Picture" style="width:100%;max-width:440px">
														</a>
														<div style="display:block;font-size:90%"></div>
													</div>
												</div>
												<div>
													<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
														<a>
															<img src="<?php bloginfo('template_url'); ?>/images/2948165_orig.png" alt="Picture" style="width:100%;max-width:880px">
														</a>
														<div style="display:block;font-size:90%"></div>
													</div>
												</div>
												<div class="paragraph" style="text-align:center;">There is no age limit for orthodontic treatment.&nbsp;
													<br>Adults can also benefit from orthodontic treatment.
												</div>					
											</td>			
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div>
						<div class="wsite-image wsite-image-border-none " style="padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
							<a>
								<img src="<?php bloginfo('template_url'); ?>/images/2232550_orig.png" alt="Picture" style="width:100%;max-width:880px">
							</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>
					<div>
						<div class="wsite-image wsite-image-border-none " style="padding-top:15px;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
							<a>
								<img src="<?php bloginfo('template_url'); ?>/images/3799221_orig.png" alt="Picture" style="width:100%;max-width:259px">
							</a>
							<div style="display:block;font-size:90%"></div>
						</div>
					</div>

					<span class="imgPusher" style="float:left;height:0px"></span>
					<span style="display: table;z-index:10;width:auto;position:relative;float:left;max-width:100%;;clear:left;margin-top:0px;*margin-top:0px">
						<a>
							<img src="<?php bloginfo('template_url'); ?>/images/4619001.png?194" style="margin-top: 5px; margin-bottom: 10px; margin-left: 0px; margin-right: 10px; border-width:1px;padding:3px; max-width:100%" alt="Picture" class="galleryImageBorder wsite-image">
						</a>
					<span style="display: table-caption; caption-side: bottom; font-size: 90%; margin-top: -10px; margin-bottom: 10px; text-align: center;" class="wsite-caption"></span>
					</span>
					<div class="paragraph" style="text-align:left;display:block;">
						Halitosis - known as bad breath to most -- is an embarrassing condition that can affect anyone at anytime, and is caused by several 
						factors. The most common causes of bad breath are preventable and easily treated, however certain medical conditions may also 
						cause bad breath. It should be addressed by your dentist.
					</div>
					<hr style="width:100%;clear:both;visibility:hidden;"></div>
				</div>
			</div>
			
			<?php
		get_footer();
	?>