<?php
function theme_guide(){
add_theme_page( 'Theme guide','Theme documentation','edit_themes', 'theme-documentation', 'fabthemes_theme_guide');
}
add_action('admin_menu', 'theme_guide');

function fabthemes_theme_guide(){
		echo '<div class="wrap">
		<div id="icon-options-general" class="icon32"><br></div>
		<h2>Theme Documentation</h2>
		
		<div class="metabox-holder">
		<div class="postbox-container" style="width:70%;">
		
		
		
				<div class="postbox"> <!-- postbox begin -->
				' . file_get_contents(dirname(__FILE__) . '/FT/license-html.php') . '
				</div> <!-- postbox end -->
				
				
				<div class="postbox"> <!-- postbox begin -->
						<h3 class="hndle"> <span> About the theme </span> </h3>
						
						<div class="inside">
						<p> Monaco is a business/Magazine theme. The homepage of the theme is arranged as below</p>
						<ol>
							<li><b>Header</b></li>
							<li><b>Featured post slider</b> - Select the category of posts and number of slides to be shown on the slider</li>
							<li><b>Site intro</b> - You have theme option to enter a site intro text</li>
							<li><b>Blog posts</b></li>
							<li><b>Footer widgets</b></li>
							<li><b>Footer</b></li>
						</ol>
							
						</div>
				</div> <!-- postbox end -->
		
	
		
		</div>
		</div>
		
		
		
		</div>';
}

 ?>
