<div id="footer"><div class="wsite-elements wsite-footer">
		<div>
			<div class="wsite-multicol"><div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
				<table class="wsite-multicol-table">
					<tbody class="wsite-multicol-tbody">
						<tr class="wsite-multicol-tr">
							<td class="wsite-multicol-col" style="width:22.130523156382%; padding:0 15px;">
								<div class="paragraph" style="text-align:left;">
									<font size="2"><font color="#d5d5d5">828 Raies Dental Clinic</font><br>
										<span style="line-height: 1.9;">
											<a href="/" title="">Home</a>
										</span>
										<br>
										<a href="/about-dr-jaizen.html" title="">About Dr. Jaizen</a><br>
										<span style="line-height: 1.9;">
											<a href="/our-clinic-and-services.html" title="">Our Clinic and Services</a>
										</span><br>
										<span style="line-height: 1.9;">
											<a href="/dental-treatments-information.html" title="">Dental Treatment Information</a>
										</span><br>
										<span style="line-height: 1.9;">
											<a href="/contact-us.html" title="">Contact Us</a>
										</span>
									</font><br>
								</div>
							</td>				
							<td class="wsite-multicol-col" style="width:20.478991577548%; padding:0 15px;">
								<div>
									<div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:10px;margin-left:0;margin-right:0;text-align:center">
										<a>
											<img src="<?php bloginfo('template_url'); ?>/images/8462030.png" alt="Picture" style="width:auto;max-width:100%">
										</a>
										<div style="display:block;font-size:90%"></div>
									</div>
								</div>
							</td>
							<td class="wsite-multicol-col" style="width:57.39048526607%; padding:0 15px;">
								<span class="imgPusher" style="float:left;height:0px"></span>
								<span style="display: table;z-index:10;width:auto;position:relative;float:left;max-width:100%;;clear:left;margin-top:0px;*margin-top:0px">
									<a href="/about-dr-jaizen.html">
										<img src="<?php bloginfo('template_url'); ?>/images/2092315.png" style="margin-top: 5px; margin-bottom: 10px; margin-left: 0px; margin-right: 10px; none; max-width:100%" alt="Picture" class="galleryImageBorder wsite-image">
									</a>
									<span style="display: table-caption; caption-side: bottom; font-size: 90%; margin-top: -10px; margin-bottom: 10px; text-align: center;" class="wsite-caption"></span>
								</span>
								<div class="paragraph" style="text-align:center;display:block;"><br>
									<span style="line-height: 1.9;">
										<font color="#d5d5d5">Know more about Dr. J or &nbsp;Dr. Jaizen Agnes Aguilar-Raies on how she have been honing and mastering her dental skills to give you the best treatment.</font>
									</span><br><br>
									<font size="1" color="#d5d5d5">
										<a href="/about-dr-jaizen.html" title="">Click here.</a>
									</font>
								</div>
								<hr style="width:100%;clear:both;visibility:hidden;">					
							</td>			
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div>
		<div class="wsite-image wsite-image-border-none " style="padding-top:10px;padding-bottom:0;margin-left:0;margin-right:0;text-align:center">
			<a>
				<img src="<?php bloginfo('template_url'); ?>/images/2478346_orig.png" alt="Picture" style="width:100%;max-width:880px">
			</a>
			<div style="display:block;font-size:90%"></div>
		</div>
	</div>
	<div>
		<div class="wsite-multicol"><div class="wsite-multicol-table-wrap" style="margin:0 -15px;">
			<table class="wsite-multicol-table">
				<tbody class="wsite-multicol-tbody">
					<tr class="wsite-multicol-tr">
						<td class="wsite-multicol-col" style="width:50%; padding:0 15px;">												
							<div class="paragraph" style="text-align:left;">
								<font color="#d5d5d5" size="2">Copyright&nbsp;©&nbsp;828 Raies Dental Clinic 2013.&nbsp;</font>
							</div>				
						</td>				
						<td class="wsite-multicol-col" style="width:50%; padding:0 15px;">											
							<div class="paragraph" style="text-align:right;">
								<font color="#d5d5d5" size="2">
									Designed by <a href="http://www.artisi.me" target="_blank">/Artisi.me</a>
								</font>
							</div>					
						</td>			
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
</div>
</div>
	
	<script type="text/javascript">

		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-7870337-1']);
		_gaq.push(['_setDomainName', 'none']);
		_gaq.push(['_setAllowLinker', true]);
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();

	</script>
	
	<script type="text/javascript">
		var _qevents = _qevents || [];

		(function() {
		var elem = document.createElement('script');
		elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge") + ".quantserve.com/quant.js";
		elem.async = true;
		elem.type = "text/javascript";
		var scpt = document.getElementsByTagName('script')[0];
		scpt.parentNode.insertBefore(elem, scpt);
		})();

		_qevents.push({
		qacct:"p-0dYLvhSGGqUWo",
		labels:"l10,u6803863.u6803863s582185447508449464"
		});
	</script>
	
	<noscript>
		<div style="display:none;">
		<img src="//pixel.quantserve.com/pixel/p-0dYLvhSGGqUWo.gif?labels=l10,u6803863.u6803863s582185447508449464" border="0" height="1" width="1" alt="Quantcast">
		</div>
	</noscript>
	
	<script>

		(function(jQuery) {
			try {
				if (jQuery) {
					jQuery('div.blog-social div.fb-like').attr('class', 'blog-social-item blog-fb-like');
					var $commentFrame = jQuery('#commentArea iframe');
					if ($commentFrame.length > 0) {
						var frameHeight = jQuery($commentFrame[0].contentWindow.document).height() + 50;
						$commentFrame.css('min-height', frameHeight + 'px');
					}
					if (jQuery('.product-button').length > 0){
						jQuery(document).ready(function(){
							jQuery('.product-button').parent().each(function(index, product){
								if(jQuery(product).attr('target') == 'paypal'){
									if (!jQuery(product).find('> [name="bn"]').length){
										jQuery('<input>').attr({
											type: 'hidden',
											name: 'bn',
											value: 'DragAndDropBuil_SP_EC'
										}).appendTo(product);
									}
								}
							});
						});
					}
				}
				else {
					// Prototype
					$$('div.blog-social div.fb-like').each(function(div) {
						div.className = 'blog-social-item blog-fb-like';
					});
					$$('#commentArea iframe').each(function(iframe) {
						iframe.style.minHeight = '410px';
					});
				}
			}
			catch(ex) {}
		})(window._W && _W.jQuery);

	</script>
	
	<div id="wsite-menus">
		<div class="wsite-menu-wrap" style="display: none; position: absolute;">
			<ul class="wsite-menu">
				<li id="wsite-nav-442726068462396283" style="position: relative;">
					<a href="/dental-treatments-information.html" style="position: relative;">
						<span class="wsite-menu-title">Dental Treatments Information</span>
					</a>
				</li>
			</ul>
		</div>
	</div>
</body>
							
</html>